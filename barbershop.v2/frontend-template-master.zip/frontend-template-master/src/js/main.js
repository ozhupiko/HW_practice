import Page from '../blocks/common/page/page';

// The page block is responsible for initialization of all other blocks
Page.initBlock();
